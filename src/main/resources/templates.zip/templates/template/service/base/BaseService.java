package ${baseServicePath};

/**
 * @author ${author}
 * @date ${date}
 * @desc Service接口通用方法
 */

public class BaseService {

}
